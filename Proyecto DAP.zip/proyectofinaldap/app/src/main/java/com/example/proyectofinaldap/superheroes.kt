package com.example.proyectofinaldap

class superheroes (
    val nombre : String,
    val desc : String
    ) {
}