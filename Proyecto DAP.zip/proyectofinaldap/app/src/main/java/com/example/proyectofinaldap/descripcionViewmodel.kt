package com.example.proyectofinaldap

import androidx.lifecycle.ViewModel

class descripcionViewmodel : ViewModel() {
}