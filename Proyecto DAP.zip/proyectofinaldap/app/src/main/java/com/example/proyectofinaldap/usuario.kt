package com.example.proyectofinaldap

class usuario (
    var username : String,
    var password : String,
)