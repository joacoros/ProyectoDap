package com.example.tpfinaldap.viewmodels

import androidx.lifecycle.ViewModel

class EditSuperHeroViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}