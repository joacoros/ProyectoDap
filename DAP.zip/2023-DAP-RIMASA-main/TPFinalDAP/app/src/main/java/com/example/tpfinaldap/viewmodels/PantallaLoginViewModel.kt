package com.example.tpfinaldap.viewmodels

import androidx.lifecycle.ViewModel

class PantallaLoginViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}